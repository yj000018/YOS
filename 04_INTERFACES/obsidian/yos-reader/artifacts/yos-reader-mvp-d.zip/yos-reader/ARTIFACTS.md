# Y-OS Reader — MVP A.1 Artifacts

**Archived:** 2026-06-06  
**Version:** 0.2.0 (patch v0.2 — sidebar-focus fix)  
**Tag:** v0.1.0-mvp-a  
**Scope:** MVP A only — YMD Reader. No MVP B work included.

---

## Artifact Inventory

| Artifact | Location | Description |
|----------|----------|-------------|
| Install ZIP | `plugins/yos-reader/artifacts/yos-reader-install.zip` | 3-file drop-in: `main.js`, `manifest.json`, `styles.css` |
| Full source ZIP | `plugins/yos-reader/artifacts/yos-reader-mvp-a.zip` | Complete source tree |
| Plugin source | `plugins/yos-reader/src/` | TypeScript source |
| Test note | `plugins/yos-reader/test/testNote.md` | AC-1 validation note |
| Parser validator | `plugins/yos-reader/test/validateParser.mjs` | Node.js AC-1/2/6 test |

---

## Acceptance Criteria — Final Status

| AC | Description | Status |
|----|-------------|--------|
| AC-1 | Test note parsed: 5 blocks, 1 per type | ✅ PASS |
| AC-2 | Titles without emoji prefix | ✅ PASS |
| AC-3 | Click navigates to heading (sidebar-focus fix applied) | ✅ PASS |
| AC-4 | Plugin never modifies the note | ✅ PASS |
| AC-5 | Sidebar refreshes on note switch, no stale data | ✅ PASS |
| AC-6 | Semantic type map extensible without parser changes | ✅ PASS |

---

## Patch Log

| Version | Change |
|---------|--------|
| v0.1.0 | Initial MVP A build |
| v0.2.0 (patch v0.2) | Fix: sidebar-focus clears panel bug; `lastMarkdownLeaf` tracking; `navigateTo` reactivates leaf; Reading View Notice |

---

## MVP Scope Confirmation

MVP B work: **NOT started**.  
This archive contains MVP A only.
